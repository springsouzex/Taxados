"use client";

import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";

const DiscordIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="currentColor"
    className="mr-2"
  >
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z" />
  </svg>
);

export default function DiscordPage() {
  const router = useRouter();

  const handleDiscordRedirect = () => {
    const discordUrl = process.env.NEXT_PUBLIC_DISCORD;
    if (!discordUrl) {
      console.error("URL do Discord não configurada no .env");
      router.push("/");
      return;
    }
    window.open(discordUrl, '_blank');
    router.back();
  };

  return (
    <div className="min-h-screen bg-[#09090b]">
      <Navbar />
      
      <div className="relative overflow-hidden">
        {/* Background com gradiente e efeito de luz */}
        <div className="fixed inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#09090b] via-purple-900/20 to-[#09090b]" />
          <div className="absolute right-0 top-[20%] w-[800px] h-[600px] bg-purple-900/20 rounded-full blur-[120px]" />
          <div className="absolute -left-20 bottom-0 w-[400px] h-[400px] bg-purple-800/10 rounded-full blur-[100px]" />
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center min-h-[calc(100vh-72px)] px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-[2.75rem] leading-tight font-bold text-white mb-6">
              Junte-se à Nossa{" "}
              <span className="text-[#8B5CF6]">
                Comunidade
              </span>
            </h1>
            
            <p className="text-[#94a3b8] text-lg mb-10 max-w-2xl mx-auto">
              Faça parte de uma comunidade dedicada a proteger e informar.
              Compartilhe experiências, aprenda e ajude outros membros.
            </p>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleDiscordRedirect}
                className="group relative inline-flex items-center justify-center"
              >
                {/* Efeito de glow */}
                <div className="absolute inset-0 rounded-xl bg-[#5865F2] blur-lg opacity-40 group-hover:opacity-60 transition-opacity duration-300" />
                
                {/* Botão principal */}
                <div className="relative inline-flex items-center px-6 py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded-xl transition-colors duration-200">
                  <DiscordIcon />
                  <span className="font-medium text-[15px]">Entrar no Servidor</span>
                </div>
              </motion.button>
            </motion.div>
          </motion.div>
        </div>

        {/* Elementos decorativos fixos */}
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-purple-500/20 rounded-full" />
        <div className="absolute top-1/3 right-1/3 w-2 h-2 bg-purple-500/20 rounded-full" />
        <div className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-purple-500/20 rounded-full" />
        <div className="absolute top-2/3 right-1/4 w-2 h-2 bg-purple-500/20 rounded-full" />
      </div>
    </div>
  );
}