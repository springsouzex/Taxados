"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Background from "@/components/Background";
import Navbar from "@/components/Navbar";
import { useRouter, useSearchParams } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState<string>("");

  // URL de autorização do Discord com o novo callback
  const DISCORD_AUTH_URL = "https://discord.com/oauth2/authorize?client_id=1321912120962584696&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fapi%2Fauth%2Fdiscord%2Fcallback&scope=identify+guilds.join+email";

  useEffect(() => {
    // Verifica se há um código de autorização na URL
    const code = searchParams.get("code");
    if (code) {
      handleDiscordCallback(code);
    }
  }, [searchParams]);

  const handleDiscordCallback = async (code: string) => {
    try {
      const response = await fetch("/api/auth/discord", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ code }),
      });

      const data = await response.json();

      if (response.ok) {
        // Salva o token no localStorage
        localStorage.setItem("authToken", data.token);
      } else {
        setError(data.message || "Erro ao fazer login");
      }
    } catch (err) {
      setError("Erro ao processar login");
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-white relative overflow-hidden">
      <Navbar />
      <Background />

      {/* Background Gradients */}
      <div className="fixed inset-0 z-0">
        {/* Base gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-[#09090b] to-[#09090b]" />
        
        {/* Gradient orbs com posições fixas */}
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-purple-600/20 rounded-full blur-[128px]" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-blue-600/20 rounded-full blur-[96px]" />
        
        {/* Grid overlay */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/90 to-transparent" />
        </div>
      </div>

      <main className="relative z-10 flex items-center justify-center min-h-screen px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Card de Login */}
          <div className="backdrop-blur-lg bg-white/5 p-8 rounded-2xl border border-white/10">
            {/* Logo/Título */}
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold mb-2">Bem-vindo ao TaxaDex</h1>
              <p className="text-gray-400">Faça login para continuar</p>
            </div>

            {/* Botão Discord */}
            <button 
              onClick={() => window.location.href = DISCORD_AUTH_URL}
              className="w-full group relative flex items-center justify-center gap-2 bg-[#5865F2] hover:bg-[#4752C4] transition-colors py-4 px-6 rounded-xl text-white font-medium"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.127a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z" />
              </svg>
              Entrar com Discord
              <svg 
                className="w-4 h-4 ml-1 transition-transform duration-200 group-hover:translate-x-0.5" 
                viewBox="0 0 24 24" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <path 
                  d="M4 12H20M20 12L14 6M20 12L14 18" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* Texto de Segurança */}
            <p className="mt-6 text-center text-sm text-gray-400">
              Suas informações estão seguras e nunca serão compartilhadas sem sua permissão.
            </p>
          </div>

          {/* Links Úteis */}
          <div className="mt-8 flex justify-center gap-6 text-sm">
            <a href="/privacy" className="text-gray-400 hover:text-white transition-colors">
              Política de Privacidade
            </a>
          </div>
        </motion.div>
      </main>

      {/* Elementos Decorativos */}
      <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-purple-500/20 rounded-full" />
      <div className="absolute top-1/3 right-1/3 w-2 h-2 bg-purple-500/20 rounded-full" />
      <div className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-purple-500/20 rounded-full" />
      <div className="absolute top-2/3 right-1/4 w-2 h-2 bg-purple-500/20 rounded-full" />
    </div>
  );
}