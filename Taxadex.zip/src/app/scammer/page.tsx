"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import Loading from "@/components/Loading";
import ImageViewer from "@/components/ImageViewer";
import scammersData from "@/database/scammers.json";

interface Proof {
  id: string;
  type: "image" | "text";
  content: string;
  description?: string;
}

interface Report {
  id: string;
  date: string;
  reason: string;
  proofs: Proof[];
}

interface Scammer {
  id: string;
  nick: string;
  nickname: string;
  avatar: string | null;
  banner: string | null;
  status: "active" | "inactive";
  reports: Report[];
  reportCount: number;
  lastReport: string;
  isFamous: boolean;
}

function CopyButton({ text, label }: { text: string, label: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1 text-gray-400 hover:text-white transition-colors"
      title={`Copiar ${label}`}
    >
      {copied ? (
        <svg 
          className="w-4 h-4 text-green-500" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth={2} 
            d="M5 13l4 4L19 7" 
          />
        </svg>
      ) : (
        <svg 
          className="w-4 h-4" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth={2} 
            d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" 
          />
        </svg>
      )}
    </button>
  );
}

export default function ScammerPage() {
  const searchParams = useSearchParams();
  const id = searchParams.get("id");
  const [scammer, setScammer] = useState<Scammer | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number>(-1);
  const [currentProofs, setCurrentProofs] = useState<{content: string, description: string, date: string}[]>([]);

  useEffect(() => {
    function fetchScammer() {
      try {
        setIsLoading(true);
        setError(null);

        if (!id) {
          setError("Nenhum ID foi fornecido");
          return;
        }

        // Busca direta no JSON
        const scammerData = (scammersData as Record<string, Scammer>)[id];
        
        if (!scammerData) {
          setError("Este usuário não se encontra em nossa database");
          return;
        }

        setScammer(scammerData);
        
        // Filtrar provas de imagem válidas
        const allImageProofs = scammerData.reports.flatMap((report: Report) => 
          report.proofs
            .filter((proof: Proof) => proof.type === "image" && proof.content)
            .map((proof: Proof) => ({
              content: proof.content,
              description: proof.description || "",
              date: report.date
            }))
        );
        setCurrentProofs(allImageProofs);
      } catch (err) {
        console.error('Erro ao carregar dados:', err);
        setError("Erro ao carregar dados do usuário");
      } finally {
        setIsLoading(false);
      }
    }

    fetchScammer();
  }, [id]);

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      // Você pode adicionar um toast/notificação aqui se desejar
    } catch (err) {
      console.error('Erro ao compartilhar:', err);
    }
  };

  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#09090b]">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Loading />
        </div>
      </div>
    );
  }

  if (error || !scammer) {
    return (
      <div className="min-h-screen bg-[#09090b]">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
            <p className="text-white text-center text-lg">
              {error || "Este usuário não se encontra em nossa database"}
            </p>
            <div className="mt-4 flex justify-center">
              <a 
                href="/scammers" 
                className="text-purple-500 hover:text-purple-400 transition-colors"
              >
                ← Voltar para a página de scammers
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b]">
      {/* Background com gradiente */}
      <div className="fixed inset-0 bg-[#09090b]">
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-purple-900/10 to-[#09090b]" />
      </div>

      <Navbar />
      
      <div className="relative z-10 pt-24">
        {/* Botão Voltar */}
        <div className="container mx-auto px-4 py-6">
          <a 
            href="/scammers" 
            className="inline-flex items-center gap-2 text-white/70 hover:text-white transition-colors"
          >
            <svg 
              className="w-5 h-5" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M10 19l-7-7m0 0l7-7m-7 7h18" 
              />
            </svg>
            <span>Voltar para a página de scammers</span>
          </a>
        </div>

        {/* Card do Perfil */}
        <div className="container mx-auto px-4">
          <div className="bg-white/5 rounded-2xl overflow-hidden border border-white/10">
            {/* Banner */}
            <div className="relative h-[250px] overflow-hidden">
              {scammer.banner ? (
                <div className="absolute inset-0">
                  <img
                    src={scammer.banner}
                    alt="Banner"
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#09090b]/80" />
                </div>
              ) : (
                <div className="w-full h-full bg-gradient-to-r from-purple-600/20 to-purple-800/20" />
              )}
            </div>

            {/* Informações do Perfil */}
            <div className="px-6">
              {/* Avatar */}
              <div className="relative -mt-20 mb-4">
                <div className="rounded-full border-4 border-[#09090b] overflow-hidden w-[130px] h-[130px]">
                  <img
                    src={scammer.avatar || `https://cdn.discordapp.com/embed/avatars/0.png`}
                    alt="Avatar"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Info */}
              <div className="pb-6">
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  {scammer.nick}
                  {scammer.isFamous && (
                    <span className="text-yellow-500 text-sm">Scammer famoso</span>
                  )}
                </h1>
                <div className="flex items-center gap-2 text-gray-400 mt-1">
                  <span>@{scammer.nickname}</span>
                  <CopyButton text={scammer.nickname} label="nickname" />
                </div>
                <div className="flex items-center gap-2 text-gray-500 text-sm mt-1">
                  <span>ID: {scammer.id}</span>
                  <CopyButton text={scammer.id} label="ID" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div className="container mx-auto px-4 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Coluna Principal */}
            <div className="lg:col-span-2 space-y-6">
              {/* Denúncias e Provas */}
              {scammer.reports.map((report, index) => (
                <div key={report.id} className="bg-white/5 rounded-2xl p-6 border border-white/10">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">
                      Denúncia #{index + 1}
                    </h2>
                    <span className="text-gray-400">
                      {formatDate(report.date)}
                    </span>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Motivo</h3>
                      <p className="text-gray-400">{report.reason}</p>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Provas</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {report.proofs
                          .filter(proof => proof.type === "image" && proof.content)
                          .map((proof, proofIndex) => (
                            <div 
                              key={proof.id} 
                              className="relative aspect-video rounded-xl overflow-hidden cursor-pointer hover:opacity-75 transition-opacity bg-white/5 max-w-[300px]"
                              onClick={() => {
                                const totalIndex = scammer.reports
                                  .slice(0, index)
                                  .reduce((acc, r) => acc + r.proofs.filter(p => p.type === "image" && p.content).length, 0);
                                setSelectedImageIndex(totalIndex + proofIndex);
                              }}
                            >
                              <img
                                src={proof.content}
                                alt="Prova"
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  e.currentTarget.src = "https://placehold.co/600x400?text=Imagem+não+disponível";
                                }}
                              />
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Coluna Lateral */}
            <div className="space-y-6">
              {/* Estatísticas */}
              <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
                <h2 className="text-xl font-bold text-white mb-6">Estatísticas</h2>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-gray-400 text-sm">Total de Denúncias</h3>
                    <p className="text-2xl font-bold text-white">{scammer.reports.length}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-gray-400 text-sm">Última Denúncia</h3>
                    <p className="text-2xl font-bold text-white">{formatDate(scammer.lastReport)}</p>
                  </div>

                  {scammer.isFamous && (
                    <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl">
                      <p className="text-yellow-400 text-sm">
                       Scammer famosinho 
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Ações */}
              <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
                <h2 className="text-xl font-bold text-white mb-6">Ações</h2>
                
                <div className="space-y-3">
                  <a
                    href={`/report`}
                    className="block w-full px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-xl transition-colors text-center"
                  >
                    <span className="inline-flex items-center">
                      Reportar Novo Caso
                    </span>
                  </a>
                  <button 
                    onClick={handleShare}
                    className="w-full px-4 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-medium rounded-xl border border-white/10 transition-colors"
                  >
                    <span className="inline-flex items-center">
                      Compartilhar Perfil
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Image Viewer */}
      {selectedImageIndex >= 0 && (
        <ImageViewer
          images={currentProofs}
          initialIndex={selectedImageIndex}
          onClose={() => setSelectedImageIndex(-1)}
        />
      )}
    </div>
  );
} 