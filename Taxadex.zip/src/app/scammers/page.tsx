"use client";

import { useEffect, useState, useRef } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Background from "@/components/Background";
import Dropdown from "@/components/Dropdown";
import { motion, AnimatePresence } from "framer-motion";
import scammersData from "@/database/scammers.json";
import Loading from '@/components/Loading';

// Definindo tipos e interfaces
interface Scammer {
  id: string;
  nickname: string;
  avatar: string;
  banner: string;
  reason: string;
  tags: string[];
  lastReport: string;
  reportCount: number;
  isFamous: boolean;
}

const FILTER_OPTIONS = ["Mais recentes", "Mais antigos", "Famosinhos"] as const;
type FilterOption = typeof FILTER_OPTIONS[number];

const ITEMS_PER_PAGE = 27;

export default function Scammers() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [scammers, setScammers] = useState<Scammer[]>([]);
  const [filter, setFilter] = useState<FilterOption>("Mais recentes");
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const searchQuery = searchParams.get("search");
    const scammerId = searchParams.get("id");

    if (scammerId) {
      const scammer = Object.values(scammersData as Record<string, Scammer>).find(s => s.id === scammerId);
      setScammers(scammer ? [scammer] : []);
    } else if (searchQuery) {
      const results = Object.values(scammersData as Record<string, Scammer>).filter(scammer => 
        scammer.nickname.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setScammers(results);
      setSearch(searchQuery);
    } else {
      setScammers(Object.values(scammersData as Record<string, Scammer>));
    }
    setIsLoading(false);
  }, [searchParams]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      router.push(`/scammers?search=${encodeURIComponent(search.trim())}`);
    }
  };

  const getFilteredScammers = () => {
    let filtered = [...scammers];

    // Aplicar busca
    if (search.trim()) {
      filtered = filtered.filter(scammer => 
        scammer.nickname.toLowerCase().includes(search.toLowerCase())
      );
    }

    // Aplicar ordenação
    filtered.sort((a, b) => {
      switch (filter) {
        case "Mais recentes":
          return new Date(b.lastReport).getTime() - new Date(a.lastReport).getTime();
        case "Mais antigos":
          return new Date(a.lastReport).getTime() - new Date(b.lastReport).getTime();
        case "Famosinhos":
          return b.reportCount - a.reportCount;
      }
    });

    if (filter === "Famosinhos") {
      filtered = filtered.filter(scammer => scammer.isFamous);
    }

    return filtered;
  };

  const filteredScammers = getFilteredScammers();
  const totalPages = Math.min(Math.ceil(filteredScammers.length / ITEMS_PER_PAGE), 2);
  const paginatedScammers = filteredScammers.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const totalScammers = scammers.length;

  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
  };

  if (isLoading) {
    return <Loading />;
  }

  return (
    <div className="min-h-screen bg-[#09090b]">
      <Background />
      <Navbar />

      <div className="relative z-10 max-w-7xl mx-auto px-4 pt-32 pb-20">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-6 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Scammers</h1>
            <p className="text-gray-400">
              Encontre e verifique golpistas reportados pela comunidade. Atualmente temos{' '}
              <span className="text-purple-500 font-semibold">
                {totalScammers} scammer{totalScammers !== 1 ? 's' : ''}
              </span>{' '}
              registrado{totalScammers !== 1 ? 's' : ''} em nossa database.
            </p>
          </div>
          
          <Link 
            href="/report"
            className="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-white px-6 py-2.5 rounded-lg font-medium transition-colors duration-200 flex items-center justify-center md:justify-start gap-2 whitespace-nowrap"
          >
            Reportar Scammer
          </Link>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Filtros */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Barra de Pesquisa */}
            <div className="relative" ref={searchRef}>
              <form onSubmit={handleSearch} className="relative">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onFocus={() => setIsFocused(true)}
                  placeholder="Pesquisar ID ou nick..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <kbd className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-gray-400">
                  CTRL + K
                </kbd>
              </form>

              <AnimatePresence>
                {isFocused && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute z-50 w-full mt-2 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-lg overflow-hidden"
                  >
                    <div className="p-2 text-sm text-gray-400">
                      Pressione Enter para buscar
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Dropdown<FilterOption>
              options={FILTER_OPTIONS}
              value={filter}
              onChange={setFilter}
              placeholder="Ordenar por"
            />
          </div>

          {/* Lista de Scammers */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 p-4">
            {paginatedScammers.map((scammer) => (
              <Link
                href={`/scammer?id=${scammer.id}`}
                key={scammer.id}
                className="block w-full bg-[#0A0A0A] rounded-xl overflow-hidden hover:bg-[#111] transition-all duration-300 border border-white/5 hover:border-purple-500/20 hover:shadow-[0_0_20px_rgba(168,85,247,0.15)]"
              >
                <div className="relative h-40">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-black z-10" />
                  <img
                    src={scammer.banner || "https://cdn.discordapp.com/attachments/1094727060760571944/1196906595661488168/banner-default.png"}
                    alt="Banner"
                    className="absolute inset-0 w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "https://cdn.discordapp.com/attachments/1094727060760571944/1196906595661488168/banner-default.png";
                    }}
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex items-start gap-4 -mt-12 relative z-20">
                    <div className="relative">
                      <div className="w-20 h-20 rounded-full border-4 border-[#0A0A0A] overflow-hidden bg-[#0A0A0A] ring-2 ring-purple-500/20">
                        <img
                          src={scammer.avatar || "https://cdn.discordapp.com/embed/avatars/0.png"}
                          alt={scammer.nickname}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="absolute -bottom-1 -right-1">
                      </div>
                    </div>
                    
                    <div className="pt-6">
                      <h2 className="text-white font-semibold text-xl tracking-tight">{scammer.nickname}</h2>
                      <p className="text-gray-500 text-sm mt-1">{scammer.reason}</p>
                    </div>
                  </div>

                  <div className="mt-6 flex flex-wrap gap-2">
                    {scammer.tags.map((tag, index) => (
                      <span key={index} className="text-purple-400 bg-purple-500/10 px-3 py-1 rounded-full text-xs font-medium">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="mt-6 flex items-center justify-between text-sm border-t border-white/5 pt-4">
                    <div>
                      <span className="text-white font-medium">{scammer.reportCount}</span>
                      <p className="text-gray-500">denúncias</p>
                    </div>
                    <div className="text-right">
                      <span className="text-gray-500">Última denúncia:</span>
                      <p className="text-white font-medium">
                        {formatDate(scammer.lastReport)}
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Nova paginação estilo navegação */}
          {filteredScammers.length > 0 && (
            <div className="flex justify-center items-center gap-2 mt-8">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 text-gray-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
              >
                <span>‹</span> Voltar
              </button>

              <div className="flex items-center gap-2 mx-4">
                {currentPage > 1 && <span className="text-gray-600">...</span>}
                
                <button
                  onClick={() => setCurrentPage(currentPage)}
                  className="px-3 py-1 rounded bg-purple-500 text-white min-w-[32px] text-center"
                >
                  {currentPage}
                </button>

                {filteredScammers.length > ITEMS_PER_PAGE && currentPage < totalPages && (
                  <span className="text-gray-600">...</span>
                )}
              </div>

              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages || filteredScammers.length <= ITEMS_PER_PAGE}
                className="px-3 py-1 text-gray-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
              >
                Avançar <span>›</span>
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}