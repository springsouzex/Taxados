import { Metadata } from 'next';
import './globals.css';
import PWAInstall from '@/components/PWAInstall';

export const metadata: Metadata = {
  title: "Taxadex - Proteção contra golpes online",
  description: "Verifique denúncias da comunidade e mantenha-se seguro nas suas transações online.",
  manifest: '/manifest.json',
  themeColor: '#09090b',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
  icons: {
    apple: [
      { url: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
      { url: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png' },
    ],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className="dark">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <meta name="apple-mobile-web-app-title" content="TaxaDex" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
      </head>
      <body className="bg-[#09090b] text-white">
        {children}
        <PWAInstall />
      </body>
    </html>
  );
}
