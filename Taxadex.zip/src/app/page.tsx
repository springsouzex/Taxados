"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Navbar from "@/components/Navbar";

export default function Home() {
  const searchParams = useSearchParams();

  useEffect(() => {
    const userData = searchParams.get("userData");
    const accessToken = searchParams.get("access_token");
    const error = searchParams.get("error");
    const errorDetails = searchParams.get("details");

    if (error) {
      console.error("Auth Error:", error);
      if (errorDetails) {
        console.error("Error Details:", JSON.parse(errorDetails));
      }
      // Aqui você pode mostrar uma mensagem de erro para o usuário
      return;
    }

    if (userData && accessToken) {
      try {
        const parsedUserData = JSON.parse(userData);
        localStorage.setItem("userData", JSON.stringify(parsedUserData));
        localStorage.setItem("accessToken", accessToken);
        
        window.history.replaceState({}, document.title, "/");
      } catch (e) {
        console.error("Error parsing user data:", e);
      }
    }
  }, [searchParams]);

  return (
    <div className="min-h-screen bg-[#09090b] text-foreground">
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-[#09090b] to-[#09090b]" />
          
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl" />
          <div className="absolute top-1/4 right-1/3 w-64 h-64 bg-purple-800/10 rounded-full blur-2xl" />
          <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-purple-700/10 rounded-full blur-3xl" />
        </div>
        
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/90 to-transparent" />
        </div>

        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/5 via-transparent to-purple-600/5 animate-pulse" />
        </div>
      </div>

      <Navbar />

      <section className="relative min-h-screen flex items-center justify-center px-4 py-20 lg:py-0">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            <div className="space-y-8 text-center lg:text-left">
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold leading-tight">
                <span>Proteja seu dinheiro</span>
                <br />
                <span>sem preocupações</span>
                <br />
                <span className="relative inline-block">
                  <span>contra </span>
                  <span className="relative">golpes online.</span>
                  <span className="absolute inset-0 rounded-lg bg-gradient-to-r from-primary/20 to-purple-500/20 blur-xl animate-pulse -z-10"></span>
                </span>
              </h1>
              <p className="text-base sm:text-lg lg:text-xl text-foreground/70 max-w-xl mx-auto lg:mx-0">
                Sistema avançado de verificação e denúncias para proteger você contra golpistas. 
                Mantenha-se seguro em suas transações online.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <a href="/scammers" className="action-button-primary group">
                  Visualizar Scammers
                  <svg className="button-arrow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
                <a href="/report" className="action-button-secondary group">
                  Denunciar Scammer
                  <svg className="button-arrow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
            </div>

            <div className="relative lg:mt-0">
              <div className="glass-card p-8 space-y-6 backdrop-blur-xl border border-nav-border shadow-xl">
                <div className="flex items-center gap-4 mb-8">
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center">
                      <svg className="w-6 h-6 sm:w-7 sm:h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#111111] animate-pulse"></div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-xl sm:text-2xl font-bold text-white">TaxaDex</h3>
                      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-purple-500/20 text-purple-400">
                        Services
                      </span>
                    </div>
                    <p className="text-white/70 text-sm sm:text-base">Proteção contra golpes</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="stats-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-white/70 flex items-center gap-2">
                        <svg className="w-4 h-4 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Denúncias verificadas
                      </span>
                      <span className="text-base sm:text-lg font-bold text-green-400">25k+</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full w-[85%] bg-gradient-to-r from-green-500 to-green-400 rounded-full"></div>
                    </div>
                  </div>

                  <div className="stats-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-white/70 flex items-center gap-2">
                        <svg className="w-4 h-4 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                        Usuários protegidos
                      </span>
                      <span className="text-base sm:text-lg font-bold text-purple-400">10k+</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full w-[65%] bg-gradient-to-r from-purple-500 to-purple-400 rounded-full"></div>
                    </div>
                  </div>

                  <div className="stats-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-white/70 flex items-center gap-2">
                        <svg className="w-4 h-4 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                        Precisão
                      </span>
                      <span className="text-base sm:text-lg font-bold text-blue-400">98%</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full w-[98%] bg-gradient-to-r from-blue-500 to-blue-400 rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}