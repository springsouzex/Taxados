"use client";

import Navbar from "@/components/Navbar";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

const ExternalLinkIcon = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="14" 
    height="14" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className="tabler-icon tabler-icon-external-link"
  >
    <path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6" />
    <path d="M11 13l9 -9" />
    <path d="M15 4h5v5" />
  </svg>
);

export default function FAQ() {
  const faqs = [
    {
      question: "O que é um Scammer?",
      answer: "Um Scammer é uma pessoa que pratica golpes ou fraudes, geralmente envolvendo produtos falsos, não entrega de itens ou outras formas de enganar pessoas na internet."
    },
    {
      question: "Como posso denunciar um Scammer?",
      answer: <>Você pode denunciar um Scammer através do nosso <a href="/report" className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1 italic">Fórum <ExternalLinkIcon /></a>. Lá você poderá criar uma denúncia formal, anexando provas como prints de conversas, comprovantes e outros documentos que comprovem o golpe.</>
    },
    {
      question: "Que tipo de provas são aceitas?",
      answer: "Aceitamos screenshots de conversas, comprovantes de pagamento, prints de anúncios falsos, vídeos de interações e qualquer outra evidência que comprove a tentativa ou realização do golpe."
    },
    {
      question: "Como verifico se alguém é um Scammer?",
      answer: <>Você pode pesquisar pelo ID ou nickname do usuário na página <a href="/scammers" className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1 italic">Scammers <ExternalLinkIcon /></a>. Se encontrar resultados, verifique as denúncias e provas apresentadas para tomar uma decisão informada.</>
    },
    {
      question: "O que acontece após uma denúncia?",
      answer: <>Após uma denúncia, nossa equipe analisa as evidências apresentadas. Se confirmado o golpe, o perfil é adicionado à lista de Scammers para alertar outros usuários. Para mais informações, entre em nosso <a href="/discord" className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1 italic">Discord <ExternalLinkIcon /></a>.</>
    },
    {
      question: "Como me proteger de Scammers?",
      answer: "Sempre verifique nossa base antes de fazer negociações, desconfie de preços muito abaixo do mercado, use intermediários confiáveis e nunca envie dinheiro sem garantias."
    },
    {
      question: "Por que alguns Scammers são marcados como 'Famosos'?",
      answer: "Scammers marcados como 'Famosos' são aqueles que possuem um alto número de denúncias ou que causaram prejuízos significativos à comunidade."
    },
    {
      question: "Como funciona o sistema de tags?",
      answer: "As tags indicam o tipo de golpe praticado pelo Scammer, como 'Produto falso', 'Não entrega', entre outros. Isso ajuda a identificar rapidamente o padrão de comportamento."
    },
    {
      question: "Posso remover meu nome da lista?",
      answer: "Casos de remoção são analisados individualmente. É necessário comprovar que houve um erro na denúncia ou que a situação foi completamente resolvida com todas as partes envolvidas."
    },
    {
      question: "Como ajudar a comunidade?",
      answer: "Você pode ajudar denunciando Scammers, compartilhando o site com amigos, participando ativamente do fórum e sempre verificando nossa base antes de fazer negociações."
    }
  ];

  return (
    <div className="min-h-screen bg-[#09090b] text-foreground relative">
      <div className="fixed inset-0 z-0">
        {/* Gradiente de fundo */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-[#09090b] to-[#09090b]" />
        </div>

        {/* Círculos de blur */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/3 w-96 h-96 bg-purple-800/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 left-1/3 w-96 h-96 bg-purple-700/20 rounded-full blur-3xl" />

        {/* Grid pattern */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-transparent to-transparent" />
        </div>

        {/* Gradiente animado */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/5 via-transparent to-purple-600/5 animate-pulse" />
        </div>
      </div>

      <Navbar />
      
      <main className="container mx-auto px-4 mt-[72px] relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto py-16"
        >
          <h1 className="text-5xl font-bold text-center text-white mb-4">Perguntas Frequentes</h1>
          <p className="text-gray-400 text-center mb-12 text-lg">Tire suas dúvidas sobre nossa plataforma anti-scam</p>
          
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-purple-500/50 transition-all duration-300"
              >
                <h2 className="text-xl font-semibold text-white mb-3 flex items-center gap-2">
                  <span className="text-purple-400">#</span>
                  {faq.question}
                </h2>
                <p className="text-gray-400 leading-relaxed">
                  {faq.answer}
                </p>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-12 p-8 bg-gradient-to-r from-purple-500/10 via-purple-600/10 to-purple-500/10 rounded-xl border border-purple-500/20 backdrop-blur-sm"
          >
            <h2 className="text-2xl font-bold text-white mb-3 text-center">
              Encontrou um Scammer?
            </h2>
            <p className="text-gray-400 mb-6 text-center">
              Denuncie agora mesmo e ajude a proteger nossa comunidade!
            </p>
            <div className="flex gap-4 justify-center">
              <a
                href="/report"
                className="px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl transition-colors font-medium flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Criar Denúncia <ExternalLinkIcon />
              </a>
              <a
                href="/discord"
                className="px-8 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-colors font-medium flex items-center gap-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
                </svg>
                Discord <ExternalLinkIcon />
              </a>
            </div>
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
} 