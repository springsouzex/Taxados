"use client";

import Navbar from "@/components/Navbar";
import { motion } from "framer-motion";

const ExternalLinkIcon = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="14" 
    height="14" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className="tabler-icon tabler-icon-external-link"
  >
    <path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6" />
    <path d="M11 13l9 -9" />
    <path d="M15 4h5v5" />
  </svg>
);

export default function Privacy() {
  const privacyItems = [
    {
      question: "Como seus dados são coletados?",
      answer: "Coletamos apenas informações essenciais para o funcionamento da plataforma, como dados das denúncias e provas fornecidas. Não armazenamos informações sensíveis ou dados pessoais além do estritamente necessário."
    },
    {
      question: "Como utilizamos suas informações?",
      answer: <>Seus dados são utilizados exclusivamente para manter um registro seguro de denúncias, identificar padrões de golpes e proteger nossa comunidade. Saiba mais em nosso <a href="/faq" className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1 italic">FAQ <ExternalLinkIcon /></a>.</>
    },
    {
      question: "Seus dados são compartilhados?",
      answer: "Não. Seus dados são confidenciais e não são compartilhados com terceiros. Todas as informações permanecem em nossa plataforma e são utilizadas apenas para proteger a comunidade contra golpes e fraudes."
    },
    {
      question: "Como protegemos suas informações?",
      answer: "Implementamos rigorosas medidas de segurança para proteger seus dados contra acessos não autorizados. Nossa infraestrutura é constantemente atualizada e monitorada para garantir a máxima proteção das informações."
    },
    {
      question: "Quais são seus direitos?",
      answer: "Você tem direito a solicitar acesso aos seus dados, requerer correções, pedir a exclusão de informações e revogar seu consentimento a qualquer momento."
    },
    {
      question: "Por quanto tempo mantemos seus dados?",
      answer: "Mantemos seus dados pelo tempo necessário para cumprir as finalidades para as quais foram coletados, incluindo obrigações legais e proteção contra fraudes."
    },
    {
      question: "Como solicitar a remoção do perfil da lista de Scammers?",
      answer: <>Para solicitar a remoção do seu perfil da lista de Scammers, você precisa comprovar que houve um erro na denúncia ou que a situação foi completamente resolvida com todas as partes envolvidas. Entre em contato através do nosso <a href="/discord" className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1 italic">Discord <ExternalLinkIcon /></a> para iniciar o processo.</>
    }
  ];

  return (
    <div className="min-h-screen bg-[#09090b] text-foreground relative">
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-[#09090b] to-[#09090b]" />
        </div>

        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/3 w-96 h-96 bg-purple-800/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 left-1/3 w-96 h-96 bg-purple-700/20 rounded-full blur-3xl" />

        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-transparent to-transparent" />
        </div>

        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/5 via-transparent to-purple-600/5 animate-pulse" />
        </div>
      </div>

      <Navbar />
      
      <main className="container mx-auto px-4 mt-[72px] relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto py-16"
        >
          <h1 className="text-5xl font-bold text-center text-white mb-4">Termos de Privacidade</h1>
          <p className="text-gray-400 text-center mb-12 text-lg">Entenda como seus dados são protegidos e utilizados na plataforma</p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10"
          >
            <div className="space-y-8">
              {privacyItems.map((item, index) => (
                <div key={index} className="space-y-3">
                  <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                    <span className="text-purple-400">#</span>
                    {item.question}
                  </h2>
                  <p className="text-gray-400 leading-relaxed">
                    {item.answer}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
} 