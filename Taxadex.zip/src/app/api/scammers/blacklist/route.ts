import { NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";

const SCAMMERS_FILE = path.join(process.cwd(), "src", "database", "scammers.json");
let cachedBlacklist: string[] = [];
let lastUpdate = 0;
const UPDATE_INTERVAL = 5 * 60 * 1000;
export async function GET() {
  try {
    const currentTime = Date.now();

    // Atualiza o cache se necessário
    if (currentTime - lastUpdate > UPDATE_INTERVAL || cachedBlacklist.length === 0) {
      const data = await fs.readFile(SCAMMERS_FILE, "utf-8");
      const scammers = JSON.parse(data);
      cachedBlacklist = Object.keys(scammers);
      lastUpdate = currentTime;
    }

    return NextResponse.json({ blacklist: cachedBlacklist });

  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
} 