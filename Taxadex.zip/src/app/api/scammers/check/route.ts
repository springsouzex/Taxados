import { NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";
import { differenceInDays, format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

const SCAMMERS_FILE = path.join(process.cwd(), "src", "database", "scammers.json");

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing scammer ID" }, { status: 400 });
    }

    const data = await fs.readFile(SCAMMERS_FILE, "utf-8");
    const scammers = JSON.parse(data);
    const scammer = scammers[id];

    if (!scammer) {
      return NextResponse.json({ exists: false });
    }

    const lastReportDate = parseISO(scammer.lastReport);
    const daysSinceLastReport = differenceInDays(new Date(), lastReportDate);
    const formattedDate = format(lastReportDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR });

    return NextResponse.json({
      exists: true,
      reportCount: scammer.reportCount,
      lastReport: {
        date: formattedDate,
        daysAgo: daysSinceLastReport
      },
      data: scammer
    });

  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
} 