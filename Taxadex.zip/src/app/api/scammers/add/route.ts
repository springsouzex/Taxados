import { NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";

const SCAMMERS_FILE = path.join(process.cwd(), "src", "database", "scammers.json");
const API_KEY = process.env.API_KEY || "6pJ7P9t6P6Et9x6Q4gMb9B2hReY9gM2Iu7RuNuH1M9Zf9Sk3pQmMrEkK4k5W";

interface Scammer {
  id: string;
  nick: string;
  nickname: string;
  avatar: string | null;
  banner: string | null;
  status: "active";
  isFamous: boolean;
  reason: string;
  tags: string[];
  reports: Array<{
    id: string;
    date: string;
    reason: string;
    proofs: Array<{
      id: string;
      type: string;
      content: string;
    }>;
  }>;
  lastReport: string;
  reportCount: number;
}

function validateApiKey(request: Request) {
  const authHeader = request.headers.get("Authorization");
  return authHeader === `Bearer ${API_KEY}`;
}

async function readScammersFile(): Promise<Record<string, Scammer>> {
  try {
    const data = await fs.readFile(SCAMMERS_FILE, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    return {};
  }
}

async function writeScammersFile(data: Record<string, Scammer>) {
  await fs.writeFile(SCAMMERS_FILE, JSON.stringify(data, null, 2));
}

export async function POST(request: Request) {
  try {
    if (!validateApiKey(request)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const data = await request.json();
    const { id, nick, nickname, avatar, banner, reason, tags, proofs } = data;

    if (!id || !reason) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const scammers = await readScammersFile();
    const currentDate = new Date().toISOString().split('T')[0];

    if (scammers[id]) {
      const newReport = {
        id: (scammers[id].reports.length + 1).toString(),
        date: currentDate,
        reason,
        proofs: proofs || []
      };

      scammers[id].reports.push(newReport);
      scammers[id].lastReport = currentDate;
      scammers[id].reportCount += 1;
      scammers[id].tags = [...new Set([...scammers[id].tags, ...tags])];
    } else {
      scammers[id] = {
        id,
        nick,
        nickname,
        avatar,
        banner,
        status: "active",
        isFamous: false,
        reason,
        tags: tags || [],
        reports: [{
          id: "1",
          date: currentDate,
          reason,
          proofs: proofs || []
        }],
        lastReport: currentDate,
        reportCount: 1
      };
    }

    await writeScammersFile(scammers);
    return NextResponse.json({ success: true });

  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
} 