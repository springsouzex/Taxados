import { NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";

const SCAMMERS_FILE = path.join(process.cwd(), "src", "database", "scammers.json");
const API_KEY = process.env.API_KEY || "6pJ7P9t6P6Et9x6Q4gMb9B2hReY9gM2Iu7RuNuH1M9Zf9Sk3pQmMrEkK4k5W";

function validateApiKey(request: Request) {
  const authHeader = request.headers.get("Authorization");
  return authHeader === `Bearer ${API_KEY}`;
}

async function readScammersFile() {
  const data = await fs.readFile(SCAMMERS_FILE, "utf-8");
  return JSON.parse(data);
}

async function writeScammersFile(data: any) {
  await fs.writeFile(SCAMMERS_FILE, JSON.stringify(data, null, 2));
}

export async function DELETE(request: Request) {
  try {
    if (!validateApiKey(request)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing scammer ID" }, { status: 400 });
    }

    const scammers = await readScammersFile();
    
    if (!scammers[id]) {
      return NextResponse.json({ error: "Scammer not found" }, { status: 404 });
    }

    delete scammers[id];
    await writeScammersFile(scammers);

    return NextResponse.json({ success: true });

  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
} 