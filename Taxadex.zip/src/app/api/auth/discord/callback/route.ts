import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const DISCORD_CLIENT_ID = "1321912120962584696";
const DISCORD_CLIENT_SECRET = "cTAWIYwwvH30LwMOaHj7a4YOqbQft2ba";

interface User {
  id: string;
  username: string;
  email: string;
  avatar: string | null;
  createdAt: string;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");

  if (!code) {
    return NextResponse.redirect(new URL("/?error=no_code", request.url));
  }

  try {
    // Configuração do request para o token
    const tokenRequestBody = new URLSearchParams({
      client_id: DISCORD_CLIENT_ID,
      client_secret: DISCORD_CLIENT_SECRET,
      grant_type: "authorization_code",
      code: code,
      redirect_uri: "http://taxadextest.squareweb.app/api/auth/discord/callback",
    });

    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: tokenRequestBody,
    });

    const tokenData = await tokenResponse.json();

    if (!tokenResponse.ok) {
      console.error("Token Error:", tokenData);
      return NextResponse.redirect(
        new URL(`/?error=token_error&details=${encodeURIComponent(JSON.stringify(tokenData))}`, request.url)
      );
    }

    // Obtém informações do usuário
    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
      },
    });

    const userData = await userResponse.json();

    if (!userResponse.ok) {
      console.error("User Data Error:", userData);
      return NextResponse.redirect(
        new URL("/?error=user_data_error", request.url)
      );
    }

    // Após obter userData com sucesso, salva no arquivo
    const usersFilePath = path.join(process.cwd(), "src", "database", "users.json");
    let users: User[] = [];

    // Lê o arquivo existente ou cria um novo
    try {
      const fileContent = fs.readFileSync(usersFilePath, "utf-8");
      users = JSON.parse(fileContent);
    } catch (_) {
      // Se o arquivo não existir, cria a pasta database
      if (!fs.existsSync(path.join(process.cwd(), "database"))) {
        fs.mkdirSync(path.join(process.cwd(), "database"));
      }
    }

    // Verifica se o usuário já existe
    const existingUserIndex = users.findIndex(u => u.id === userData.id);
    const newUser: User = {
      id: userData.id,
      username: userData.username,
      email: userData.email,
      avatar: userData.avatar 
        ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`
        : null,
      createdAt: new Date().toISOString()
    };

    if (existingUserIndex >= 0) {
      users[existingUserIndex] = { ...users[existingUserIndex], ...newUser };
    } else {
      users.push(newUser);
    }

    // Salva no arquivo
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));

    // Cria o objeto com os dados do usuário
    const user = {
      id: userData.id,
      username: userData.username,
      email: userData.email,
      avatar: userData.avatar 
        ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`
        : null,
    };

    // Redireciona para a home com os dados do usuário
    const redirectUrl = new URL("/", request.url);
    redirectUrl.searchParams.set("userData", JSON.stringify(user));
    redirectUrl.searchParams.set("access_token", tokenData.access_token);

    return NextResponse.redirect(redirectUrl);

  } catch (error) {
    console.error("Full Auth Error:", error);
    return NextResponse.redirect(
      new URL(`/?error=auth_failed&details=${encodeURIComponent(error?.toString() || '')}`, request.url)
    );
  }
} 