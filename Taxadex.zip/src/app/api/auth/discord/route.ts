import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { SignJWT } from "jose";

const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET;
const DISCORD_REDIRECT_URI = process.env.DISCORD_REDIRECT_URI;
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

interface DiscordUser {
  id: string;
  username: string;
  email: string;
  avatar: string;
}

interface User {
  id: number;
  discordId: string;
  username: string;
  email: string;
  avatar: string;
  createdAt: string;
}

export async function POST(request: Request) {
  try {
    const { code } = await request.json();

    // Troca o código por um token de acesso
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID!,
        client_secret: DISCORD_CLIENT_SECRET!,
        grant_type: "authorization_code",
        code: code as string,
        redirect_uri: DISCORD_REDIRECT_URI!,
      }),
    });

    const tokenData = await tokenResponse.json();

    // Obtém informações do usuário
    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
      },
    });

    const userData: DiscordUser = await userResponse.json();

    // Lê o arquivo de usuários
    const usersPath = path.join(process.cwd(), "src", "database", "users.json");
    let users: User[] = [];
    
    try {
      const usersData = fs.readFileSync(usersPath, "utf-8");
      users = JSON.parse(usersData);
    } catch (_) {
      // Se o arquivo não existir, cria um novo
      fs.writeFileSync(usersPath, "[]");
    }

    // Verifica se o usuário já existe
    let user = users.find((u) => u.discordId === userData.id);

    if (!user) {
      // Cria novo usuário
      user = {
        id: users.length + 1,
        discordId: userData.id,
        username: userData.username,
        email: userData.email,
        avatar: `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`,
        createdAt: new Date().toISOString(),
      };

      users.push(user);
      fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
    }

    // Gera token JWT usando jose
    const token = await new SignJWT({ 
      userId: user.id,
      discordId: user.discordId,
      username: user.username 
    })
      .setProtectedHeader({ alg: "HS256" })
      .setExpirationTime("7d")
      .sign(new TextEncoder().encode(JWT_SECRET));

    return NextResponse.json({ token, user });
  } catch (error) {
    console.error("Auth error:", error);
    return NextResponse.json(
      { message: "Erro na autenticação" },
      { status: 500 }
    );
  }
} 