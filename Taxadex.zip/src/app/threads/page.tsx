"use client";

import Background from "@/components/Background";
import Navbar from "@/components/Navbar";

export default function Threads() {
  return (
    <div className="relative min-h-screen bg-[#0A0A0B]">
      <Navbar />
      <Background />
      
      <div className="relative z-10 w-full max-w-[1400px] mx-auto px-3 sm:px-6 pt-20 sm:pt-24">
        <div className="flex items-center justify-center min-h-[60vh]">
          <h1 className="text-3xl sm:text-4xl font-bold text-white">Disponível em breve</h1>
        </div>
      </div>
    </div>
  );
} 