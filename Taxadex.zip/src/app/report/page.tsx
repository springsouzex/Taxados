"use client";

import { motion } from "framer-motion";
import { Shield, MessageCircle, AlertTriangle, Users, Clock, FileText, CheckCircle2, ShieldAlert, Eye } from "lucide-react";
import Navbar from "@/components/Navbar";

const ExternalLinkIcon = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="14" 
    height="14" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className="tabler-icon tabler-icon-external-link"
  >
    <path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6" />
    <path d="M11 13l9 -9" />
    <path d="M15 4h5v5" />
  </svg>
);

const features = {
  forum: [
    {
      icon: <FileText className="w-5 h-5 text-purple-400" />,
      title: "Formato Organizado",
      description: "Sistema estruturado para denúncias"
    },
    {
      icon: <Users className="w-5 h-5 text-purple-400" />,
      title: "Comunidade Ativa",
      description: "Suporte da comunidade"
    },
    {
      icon: <Eye className="w-5 h-5 text-purple-400" />,
      title: "Maior Visibilidade",
      description: "Denúncias indexadas"
    }
  ],
  discord: [
    {
      icon: <Clock className="w-5 h-5 text-purple-400" />,
      title: "Resposta Rápida",
      description: "Atendimento em tempo real"
    },
    {
      icon: <ShieldAlert className="w-5 h-5 text-purple-400" />,
      title: "Moderação Direta",
      description: "Contato com moderadores"
    },
    {
      icon: <CheckCircle2 className="w-5 h-5 text-purple-400" />,
      title: "Processo Ágil",
      description: "Resolução eficiente"
    }
  ]
};

export default function Report() {
  return (
    <div className="min-h-screen bg-[#09090b] text-white relative overflow-hidden">
      {/* Background Effects */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-[#09090b] to-[#09090b]" />
        <div className="absolute top-0 left-1/4 w-[400px] h-[400px] bg-purple-600/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/3 right-1/3 w-[400px] h-[400px] bg-purple-800/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-transparent to-transparent" />
      </div>

      <Navbar />

      <main className="relative z-10 container mx-auto px-4 mt-[72px]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-5xl mx-auto py-12"
        >
          <div className="text-center mb-12">
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-block p-3 bg-red-500/10 rounded-xl mb-4 backdrop-blur-sm"
            >
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </motion.div>
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white via-purple-200 to-white bg-clip-text text-transparent">
              Denunciar Scammer
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto text-base">
              Proteja nossa comunidade reportando atividades suspeitas.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Forum Card */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-purple-800/10 rounded-xl blur-xl group-hover:blur-2xl transition-all duration-300" />
              <a href="/threads" className="block relative">
                <div className="p-7 rounded-xl bg-white/5 border border-white/10 hover:border-purple-500/50 transition-all duration-300 backdrop-blur-sm">
                  <div className="bg-purple-500/10 p-3 rounded-lg w-fit mb-4">
                    <MessageCircle className="w-6 h-6 text-purple-400" />
                  </div>
                  <h2 className="text-2xl font-semibold mb-3 flex items-center gap-2 group-hover:text-purple-400 transition-colors">
                    Fórum da Comunidade <ExternalLinkIcon />
                  </h2>
                  <p className="text-gray-400 mb-6 text-base">
                    Crie uma denúncia detalhada com todas as evidências necessárias.
                  </p>
                  <div className="grid gap-4 mb-6">
                    {features.forum.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="p-2 bg-purple-500/10 rounded-lg">
                          {feature.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-white">{feature.title}</h3>
                          <p className="text-gray-400 text-sm">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="pt-5 border-t border-white/10">
                    <span className="text-base text-purple-400 font-medium flex items-center gap-2 hover:text-purple-300 transition-colors">
                      Criar denúncia <ExternalLinkIcon />
                    </span>
                  </div>
                </div>
              </a>
            </motion.div>

            {/* Discord Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-purple-800/10 rounded-xl blur-xl group-hover:blur-2xl transition-all duration-300" />
              <a href="/discord" className="block relative">
                <div className="p-7 rounded-xl bg-white/5 border border-white/10 hover:border-purple-500/50 transition-all duration-300 backdrop-blur-sm">
                  <div className="bg-purple-500/10 p-3 rounded-lg w-fit mb-4">
                    <Shield className="w-6 h-6 text-purple-400" />
                  </div>
                  <h2 className="text-2xl font-semibold mb-3 flex items-center gap-2 group-hover:text-purple-400 transition-colors">
                    Suporte Discord <ExternalLinkIcon />
                  </h2>
                  <p className="text-gray-400 mb-6 text-base">
                    Reporte diretamente para nossa equipe de moderação.
                  </p>
                  <div className="grid gap-4 mb-6">
                    {features.discord.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="p-2 bg-purple-500/10 rounded-lg">
                          {feature.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-white">{feature.title}</h3>
                          <p className="text-gray-400 text-sm">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="pt-5 border-t border-white/10">
                    <span className="text-base text-purple-400 font-medium flex items-center gap-2 hover:text-purple-300 transition-colors">
                      Acessar Discord <ExternalLinkIcon />
                    </span>
                  </div>
                </div>
              </a>
            </motion.div>
          </div>
        </motion.div>
      </main>
    </div>
  );
} 