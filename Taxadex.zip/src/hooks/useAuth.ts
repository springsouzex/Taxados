import { useState, useEffect } from "react";
import type { JwtPayload } from "jwt-decode";
import { jwtDecode } from "jwt-decode";

interface User extends JwtPayload {
  userId: number;
  discordId: string;
  username: string;
}

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    
    if (token) {
      try {
        const decoded = jwtDecode<User>(token);
        setUser(decoded);
        setIsAuthenticated(true);
      } catch (err) {
        localStorage.removeItem("authToken");
      }
    }
    
    setLoading(false);
  }, []);

  const logout = () => {
    localStorage.removeItem("authToken");
    setUser(null);
    setIsAuthenticated(false);
  };

  return { isAuthenticated, user, loading, logout };
} 