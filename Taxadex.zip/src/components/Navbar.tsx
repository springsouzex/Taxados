"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { Menu, X, Settings, LogOut, User, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface User {
  id: string;
  username: string;
  email: string;
  avatar: string | null;
}

export default function Navbar() {
  const router = useRouter();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Verificar se existe token no localStorage
    const checkAuth = async () => {
      const token = localStorage.getItem('accessToken');
      if (token) {
        try {
          const response = await fetch('https://discord.com/api/users/@me', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          if (response.ok) {
            const userData = await response.json();
            setUser({
              id: userData.id,
              username: userData.username,
              avatar: `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`,
              email: userData.email,
            });
            localStorage.setItem("userData", JSON.stringify(userData));
          }
        } catch (error) {
          console.error('Erro ao buscar dados do usuário:', error);
        }
      }
    };
    checkAuth();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem("userData");
    setUser(null);
    router.push('/');
    setMobileMenuOpen(false);
    setProfileDropdownOpen(false);
    window.location.reload();
  };

  if (!mounted) return null;

  const menuItems = [
    { name: 'Início', href: '/' },
    { name: 'Scammers', href: '/scammers' },
    { name: 'Franquias', href: '/franchise' },
    { name: 'Fórum', href: '/threads' },
    { name: 'FAQ', href: '/faq' },
  ];

  return (
    <header className="fixed w-full top-0 z-50">
      <div className="navbar max-w-7xl mx-auto my-4 px-4 sm:px-6 py-3 rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/" className="text-white font-medium flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600/90 to-purple-700/90 flex items-center justify-center shadow-lg shadow-purple-500/10">
              <span className="font-bold">T</span>
            </div>
            <span className="text-lg hidden sm:inline">TaxaDex</span>
          </Link>
        </div>

        <nav className="hidden lg:flex items-center gap-1 bg-black/20 rounded-full px-2 py-1 backdrop-blur-lg border border-white/[0.03]">
          {menuItems.slice(0, 7).map((item) => (
            <Link key={item.name} href={item.href} className="nav-item">
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-4">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Pesquisar id ou nick..." 
              className="search-input"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <span className="text-xs text-gray-500 px-1.5 py-0.5 rounded bg-white/5">CTRL + K</span>
            </div>
          </div>

          <div className="nav-button-group">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 hover:bg-white/5 p-1 rounded-lg transition-colors"
                >
                  <div className="relative w-8 h-8">
                    <Image 
                      src={user.avatar || "/default-avatar.png"}
                      alt={user.username}
                      fill
                      className="rounded-full object-cover"
                    />
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>

                <AnimatePresence>
                  {profileDropdownOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute right-0 mt-2 w-48 bg-[#1a1a1a] rounded-lg shadow-lg border border-white/10 overflow-hidden"
                    >
                      <div className="py-1">
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center gap-2 px-4 py-2 text-sm text-gray-200 hover:bg-white/5"
                        >
                          <LogOut className="w-4 h-4" />
                          Logout
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <Link href="/login" className="nav-button">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </Link>
            )}

            <Link href="/discord" className="nav-button">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.27 5.33C17.94 4.71 16.5 4.26 15 4a.09.09 0 0 0-.07.03c-.18.33-.39.76-.53 1.09a16.09 16.09 0 0 0-4.8 0c-.14-.34-.35-.76-.54-1.09c-.01-.02-.04-.03-.07-.03c-1.5.26-2.93.71-4.27 1.33c-.01 0-.02.01-.03.02c-2.72 4.07-3.47 8.03-3.1 11.95c0 .02.01.04.03.05c1.8 1.32 3.53 2.12 5.24 2.65c.03.01.06 0 .07-.02c.4-.55.76-1.13 1.07-1.74c.02-.04 0-.08-.04-.09c-.57-.22-1.11-.48-1.64-.78c-.04-.02-.04-.08-.01-.11c.11-.08.22-.17.33-.25c.02-.02.05-.02.07-.01c3.44 1.57 7.15 1.57 10.55 0c.02-.01.05-.01.07.01c.11.09.22.17.33.26c.04.03.04.09-.01.11c-.52.31-1.07.56-1.64.78c-.04.01-.05.06-.04.09c.32.61.68 1.19 1.07 1.74c.03.01.06.02.09.01c1.72-.53 3.45-1.33 5.25-2.65c.02-.01.03-.03.03-.05c.44-4.53-.73-8.46-3.1-11.95c-.01-.01-.02-.02-.04-.02zM8.52 14.91c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12c0 1.17-.84 2.12-1.89 2.12zm6.97 0c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12c0 1.17-.83 2.12-1.89 2.12z"/>
              </svg>
            </Link>
          </div>
        </div>

        <button 
          className="lg:hidden text-white/70 hover:text-white p-2"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {isMenuOpen && (
        <div className="mobile-menu">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4">
              <div className="w-8 h-8 rounded-lg bg-[#9333EA] flex items-center justify-center">
                <span className="font-bold text-white">T</span>
              </div>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="nav-button"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="px-4 py-2">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Pesquisar id ou nick..." 
                  className="search-input w-full"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <span className="text-xs text-gray-500 px-1.5 py-0.5 rounded bg-white/5">CTRL + K</span>
                </div>
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto py-4">
              <div className="px-4 space-y-1">
                {menuItems.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-white/70 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                  >
                    {item.name}
                  </Link>
                ))}

                <div className="h-px bg-white/5 my-4" />

                {user && (
                  <div className="pt-4 border-t border-white/10">
                    <div className="flex items-center justify-between p-4 bg-zinc-900/60 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="relative w-10 h-10">
                          <Image 
                            src={user.avatar || "/default-avatar.png"}
                            alt={user.username}
                            fill
                            className="rounded-full object-cover"
                          />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-white">Minha conta</span>
                          <span className="text-xs text-zinc-400">{user.id}</span>
                        </div>
                      </div>
                      <button
                        onClick={handleLogout}
                        className="p-2 hover:bg-white/5 rounded-lg transition-colors"
                      >
                        <LogOut className="w-5 h-5 text-zinc-400" />
                      </button>
                    </div>
                  </div>
                )}
                
                {!user && (
                  <Link href="/login" className="nav-button">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </Link>
                )}
              </div>
            </nav>
          </div>
        </div>
      )}

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden bg-black/10 backdrop-blur-lg border-b border-white/10"
          >
            <div className="px-4 py-6 space-y-4">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Pesquisar id ou nick..." 
                  className="search-input w-full"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <span className="text-xs text-gray-500 px-1.5 py-0.5 rounded bg-white/5">CTRL + K</span>
                </div>
              </div>

              <nav className="flex-1 overflow-y-auto py-4">
                <div className="px-4 space-y-1">
                  {menuItems.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 text-sm text-white/70 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}

                  <div className="h-px bg-white/5 my-4" />

                  {user ? (
                    <div className="pt-4 border-t border-white/10">
                      <div className="flex items-center justify-between p-4 bg-zinc-900/60 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="relative w-10 h-10">
                            <Image 
                              src={user.avatar || "/default-avatar.png"}
                              alt={user.username}
                              fill
                              className="rounded-full object-cover"
                            />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-sm font-medium text-white">Minha conta</span>
                            <span className="text-xs text-zinc-400">{user.id}</span>
                          </div>
                        </div>
                        <button
                          onClick={handleLogout}
                          className="p-2 hover:bg-white/5 rounded-lg transition-colors"
                        >
                          <LogOut className="w-5 h-5 text-zinc-400" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <Link href="/login" className="nav-button">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </Link>
                  )}
                </div>
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}