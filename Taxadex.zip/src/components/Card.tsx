import { LucideIcon } from 'lucide-react';

interface CardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

export default function Card({ icon: Icon, title, description, href }: CardProps) {
  return (
    <a 
      href={href}
      className="bg-[#141414] rounded-lg p-5 hover:bg-[#1A1A1A] transition-colors border border-[#2A2A2A] cursor-pointer block"
    >
      <div className="flex items-center gap-3 mb-3">
        <Icon className="w-5 h-5 text-gray-300" />
        <h3 className="text-lg font-medium text-white">{title}</h3>
      </div>
      <p className="text-sm text-gray-400">{description}</p>
    </a>
  );
} 