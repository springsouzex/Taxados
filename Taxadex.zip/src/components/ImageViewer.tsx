"use client";

import { useState, useEffect, useRef } from "react";

interface ImageViewerProps {
  images: { content: string }[];
  initialIndex: number;
  onClose: () => void;
}

const ImageViewer: React.FC<ImageViewerProps> = ({ images, initialIndex, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [isZoomed, setIsZoomed] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const imageRef = useRef<HTMLImageElement>(null);

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : images.length - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev < images.length - 1 ? prev + 1 : 0));
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "ArrowLeft") handlePrevious();
    if (e.key === "ArrowRight") handleNext();
    if (e.key === "Escape") onClose();
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageRef.current) return;

    const rect = imageRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setMousePosition({ x, y });
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
      onClick={handleBackdropClick}
    >
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Botão Fechar */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/70 hover:text-white z-50"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Container da Imagem e Zoom */}
        <div className="relative flex items-center gap-8" onClick={(e) => e.stopPropagation()}>
          {/* Botão Anterior - Mobile */}
          <button
            onClick={handlePrevious}
            className="absolute left-2 md:left-4 z-30 text-white/70 hover:text-white bg-black/20 rounded-full p-2 md:p-0 md:bg-transparent"
          >
            <svg className="w-6 h-6 md:w-8 md:h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          {/* Imagem Principal */}
          <div className="relative">
            <div 
              className="relative max-w-3xl max-h-[80vh]"
              onMouseMove={handleMouseMove}
              style={{ cursor: isZoomed ? 'crosshair' : 'default' }}
            >
              <img
                ref={imageRef}
                src={images[currentIndex].content}
                alt="Prova"
                className="max-h-[80vh] rounded-lg"
                onError={(e) => {
                  e.currentTarget.src = "https://placehold.co/600x400?text=Imagem+não+disponível";
                }}
              />
              
              {/* Indicador de área do zoom - Aumentado para 40x40 */}
              {isZoomed && (
                <div
                  className="pointer-events-none absolute w-40 h-40 border-2 border-white/50 rounded-lg hidden md:block"
                  style={{
                    left: `calc(${mousePosition.x}% - 80px)`,
                    top: `calc(${mousePosition.y}% - 80px)`,
                  }}
                />
              )}
            </div>

            {/* Botão de Zoom - Apenas Desktop */}
            <button
              onClick={() => setIsZoomed(!isZoomed)}
              className="absolute -top-12 left-1/2 -translate-x-1/2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white/70 hover:text-white transition-all items-center gap-2 hidden md:flex"
            >
              <svg 
                className="w-5 h-5" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                {isZoomed ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10h-4v4" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v4m0 0v4m0-4h4m-4 0H6" />
                )}
              </svg>
              {isZoomed ? 'Desativar Zoom' : 'Ativar Zoom'}
            </button>
          </div>

          {/* Área de Zoom - Aumentada a ampliação para 600% */}
          {isZoomed && (
            <div 
              className="w-[500px] h-[500px] rounded-lg border-2 border-white/10 overflow-hidden bg-black/50 hidden md:block"
              style={{
                backgroundImage: `url(${images[currentIndex].content})`,
                backgroundPosition: `${mousePosition.x}% ${mousePosition.y}%`,
                backgroundSize: '600%',
                backgroundRepeat: 'no-repeat',
              }}
            />
          )}

          {/* Botão Próximo - Mobile */}
          <button
            onClick={handleNext}
            className="absolute right-2 md:right-4 z-30 text-white/70 hover:text-white bg-black/20 rounded-full p-2 md:p-0 md:bg-transparent"
          >
            <svg className="w-6 h-6 md:w-8 md:h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImageViewer; 