export default function Background() {
  return (
    <div className="fixed inset-0 z-0">
      {/* Gradientes de fundo */}
      <div className="absolute inset-0">
        {/* Gradiente roxo principal - mais suave */}
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/10 via-[#09090b] to-[#09090b]" />
        
        {/* Efeitos de luz roxa - mais suaves */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl" />
        <div className="absolute top-1/4 right-1/3 w-64 h-64 bg-purple-800/5 rounded-full blur-2xl" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-purple-700/5 rounded-full blur-3xl" />
      </div>

      {/* Grid com fade */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/90 to-transparent" />
      </div>

      {/* Efeito de brilho animado - mais suave */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/[0.02] via-transparent to-purple-600/[0.02] animate-pulse" />
      </div>
    </div>
  );
} 