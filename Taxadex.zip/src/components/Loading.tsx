"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function Loading() {
  const [particles, setParticles] = useState<Array<{ id: number; delay: number; x: number }>>([]);
  const [dimensions, setDimensions] = useState({ width: 1000, height: 1000 });

  useEffect(() => {
    setDimensions({
      width: window.innerWidth,
      height: window.innerHeight
    });

    const newParticles = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      delay: Math.random() * 5,
      x: Math.random() * 1000
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-white dark:bg-[#09090b] transition-colors duration-200">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          initial={{ 
            x: particle.x,
            y: -20,
            opacity: 0,
            scale: 0
          }}
          animate={{ 
            x: particle.x - 100,
            y: dimensions.height + 20,
            opacity: [0, 1, 1, 0],
            scale: [0, 1, 0.5, 0],
            rotate: Math.random() * 360
          }}
          transition={{ 
            duration: 4 + Math.random() * 2,
            repeat: Infinity,
            delay: particle.delay,
            ease: "easeOut"
          }}
          className="absolute w-3 h-3"
        >
          <div className="w-full h-full bg-gradient-to-br from-purple-400 to-purple-600 rounded-full blur-[2px]" />
        </motion.div>
      ))}

      <div className="flex flex-col items-center justify-center">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{
            duration: 0.8,
            ease: "easeOut"
          }}
          className="relative"
        >
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute inset-0 bg-purple-600/30 rounded-2xl blur-xl"
          />
          
          <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center shadow-lg shadow-purple-500/20">
            <motion.span 
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-4xl font-bold text-white"
            >
              T
            </motion.span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center"
        >
          <motion.h2 
            className="text-2xl font-bold text-gray-900 dark:text-white mb-2"
          >
            TaxaDex
          </motion.h2>
          <p className="text-sm text-gray-600 dark:text-purple-400">Carregando...</p>
        </motion.div>
      </div>
    </div>
  );
} 